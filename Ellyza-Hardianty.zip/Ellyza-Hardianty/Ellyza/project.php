<!DOCTYPE html>
<html lang="en" class="no-js">
<head>
    <!-- Metadata dasar halaman -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Project - Ellyza</title>

    <!-- JavaScript untuk menangani skenario tanpa-JS -->
    <script>
        document.documentElement.classList.remove('no-js');
        document.documentElement.classList.add('js');
    </script>

    <!-- Link ke file CSS eksternal -->
    <link rel="stylesheet" href="css/vendor.css">
    <link rel="stylesheet" href="css/styles.css">

    <!-- Ikon favicon untuk berbagai perangkat -->
    <link rel="apple-touch-icon" sizes="180x180" href="apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="favicon-16x16.png">
    <link rel="manifest" href="site.webmanifest">
</head>

<body id="top">

    <!-- Preloader sebelum konten utama dimuat -->
    <div id="preloader">
        <div id="loader" class="dots-fade">
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>

    <!-- Pembungkus Halaman Utama -->
    <div id="page" class="s-pagewrap">

        <!-- Header Situs -->
        <header class="s-header">
            <div class="row s-header__inner width-sixteen-col">

                <!-- Navigasi Utama -->
                <nav class="s-header__nav">
                    <ul class="s-header__menu-links">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="about.php">About</a></li>
                        <li><a href="project.php">Project</a></li>
                        <li><a href="skill.php">Skill</a></li>
                        <li><a href="contact.php">Contact</a></li>
                    </ul>
                </nav> <!-- Akhir navigasi utama -->
            </div> <!-- Akhir header__inner -->
        </header> <!-- Akhir header situs -->

        <!-- Konten Utama Halaman -->
<?php
include "koneksi.php";
$sql = "SELECT title, description FROM projects";
$result = $conn->query($sql);

$content = '';

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $content .= '<div class="grid-list-items__item list-items__item">';
        $content .= '<div class="list-items__item-header">';
        $content .= '<h3 class="list-items__item-title">' . $row['title'] . '</h3>';
        $content .= '</div>';
        $content .= '<div class="list-items__item-text" style="text-align: justify;">';
        $content .= '<p>' . $row['description'] . '</p>';
        $content .= '</div>';
        $content .= '</div>'; 
    }
} else {
    $content = '<p>No projects found.</p>';
}

$conn->close();
?>

<section id="content" class="s-content">

    <!-- Header Halaman Project -->
    <section class="s-pageheader pageheader">
        <div class="row">
            <div class="column xl-12">
                <!-- Judul halaman Project -->
                <h1 class="page-title">
                    <span class="page-title__small-type text-pretitle">Project</span>
                    High Impact Project
                </h1>
            </div>
        </div>
    </section> <!-- Akhir header halaman -->

    <!-- Konten Project -->
    <section class="s-pagecontent pagecontent">
        <div class="row">
            <div class="column xl-12 grid-block">

                <!-- Daftar Project/Pengalaman -->
                <div class="grid-full grid-list-items list-items show-ctr">
                    <?php echo $content; ?>
                </div> <!-- Akhir grid-list-items -->
            </div> <!-- Akhir kolom grid-block -->
        </div> <!-- Akhir row -->
    </section> <!-- Akhir pagecontent -->
</section> <!-- Akhir konten utama -->

    <!-- JavaScript Eksternal -->
    <script src="js/plugins.js"></script>
    <script src="js/main.js"></script>
</body>
</html>
