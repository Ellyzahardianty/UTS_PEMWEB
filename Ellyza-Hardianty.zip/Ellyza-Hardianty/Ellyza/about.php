<!DOCTYPE html>
<html lang="en" class="no-js">

<head>
    <!-- Metadata dasar halaman -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>About Me - Ellyza</title>

    <!-- JavaScript untuk mengaktifkan fitur-fitur pada halaman -->
    <script>
        // Tambahkan class 'js' jika JavaScript aktif
        document.documentElement.classList.remove('no-js');
        document.documentElement.classList.add('js');
    </script>

    <!-- CSS -->
    <link rel="stylesheet" href="css/vendor.css">
    <link rel="stylesheet" href="css/styles.css">

    <!-- Ikon favorit untuk berbagai perangkat -->
    <link rel="apple-touch-icon" sizes="180x180" href="apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="favicon-16x16.png">
    <link rel="manifest" href="site.webmanifest">

    <!-- CSS tambahan untuk ukuran gambar -->
    <style>
        /* Mengatur ukuran maksimal gambar agar lebih kecil */
        .img-container img {
            max-width: 950px; /* Sesuaikan ukuran sesuai kebutuhan */
            height: auto;
            margin: 0 auto; /* Pusatkan gambar */
            display: block;
        }
    </style>
</head>

<body id="top">

    <!-- Preloader animasi sebelum konten muncul -->
    <div id="preloader">
        <div id="loader" class="dots-fade">
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>

    <!-- Pembungkus halaman utama -->
    <div id="page" class="s-pagewrap">

        <!-- Header situs dengan background -->
        <header class="s-header navbar-background">
            <div class="row s-header__inner width-sixteen-col">

                <!-- Navigasi halaman -->
                <nav class="s-header__nav">
                    <ul class="s-header__menu-links">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="about.php">About</a></li>
                        <li><a href="project.php">Project</a></li>
                        <li><a href="skill.php">Skill</a></li>
                        <li><a href="contact.php">Contact</a></li>
                    </ul>
                </nav> <!-- end s-header__nav -->
            </div> <!-- end s-header__inner -->
        </header> <!-- end s-header -->

        <!-- Konten utama halaman About -->
         <?php 
        // Query untuk mengambil data
        include "koneksi.php";
            $sql = "SELECT * FROM about WHERE id = 1"; 
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                // Menampilkan data
                while($row = $result->fetch_assoc()) {
                    ?>

            <section id="content" class="s-content">
                <!-- Header halaman About dengan judul -->
                <section class="s-pageheader pageheader">
                    <div class="row">
                        <div class="column xl-12">
                            <h1 class="page-title">
                                <span class="page-title__small-type text-pretitle">About Me</span>
                                Hello Everyone!!
                            </h1>
                        </div>
                    </div>
                </section> <!-- end pageheader -->

                <!-- Gambar profil pada halaman About -->
                <div class="row pagemedia">
                    <div class="column xl-12">
                        <figure class="page-media img-container">
                            <img src="ellyza.jpg" 
                                srcset="ellyza.jpg 2400w, 
                                        ellyza.jpg 1200w, 
                                        ellyza.jpg 600w" 
                                sizes="(max-width: 2400px) 100vw, 2400px" 
                                alt="Profile Image"> 
                        </figure>
                    </div>
                </div>

                <!-- Deskripsi tentang diri dan perjalanan karier -->
                <div class="row width-narrower pagemain">
                    <div class="column xl-12" style="text-align: justify;">
                        <h2>I am <?php echo $row["name"]; ?></h2>
                        <p>
                            Hi, I'm <?php echo $row["name"]; ?>, an <?php echo $row["description"]; ?>
                        </p>
                        <p>
                            Besides being active in organizations, <?php echo $row["interests"]; ?>
                        </p>
                        <p>
                            I am always eager to learn, take on new challenges, and look forward to building a successful career in technology.
                        </p>
                    </div>
                </div>
            </section> <!-- end s-content -->

            <?php
                }
            } else {
                echo "<p>Data tidak ditemukan</p>";
            }

            $conn->close();
            ?>

    </div> <!-- End of page wrapper -->

    <!-- JavaScript -->
    <script src="js/plugins.js"></script>
    <script src="js/main.js"></script>

</body>
</html>
