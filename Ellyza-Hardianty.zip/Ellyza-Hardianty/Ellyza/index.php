<!DOCTYPE html>
<html lang="en" class="no-js">
<head>

    <!-- Kebutuhan dasar halaman
    ================================================== -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Ellyza</title>

    <!-- Menambahkan class 'js' pada elemen HTML jika JavaScript aktif -->
    <script>
        document.documentElement.classList.remove('no-js');
        document.documentElement.classList.add('js');
    </script>

    <!-- CSS untuk tampilan halaman -->
    <link rel="stylesheet" href="css/vendor.css">
    <link rel="stylesheet" href="css/styles.css">

    <!-- Ikon favorit
    ================================================== -->
    <link rel="apple-touch-icon" sizes="180x180" href="apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="favicon-16x16.png">
    <link rel="manifest" href="site.webmanifest">

</head>

<body id="top">

    <!-- Preloader untuk animasi loading sebelum halaman selesai dimuat -->
    <div id="preloader">
        <div id="loader" class="dots-fade">
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>

    <!-- Bungkus halaman utama -->
    <div id="page" class="s-pagewrap ss-home">

        <!-- Header situs 
        ================================================== -->
        <header class="s-header">
            <div class="row s-header__inner width-sixteen-col">

                <div class="s-header__block">
                    <div class="s-header__logo">
                        <!-- Tempat logo situs -->
                    </div>

                    <!-- Tombol menu untuk navigasi mobile -->
                    <a class="s-header__menu-toggle" href="#0"><span>Menu</span></a>
                </div> <!-- end s-header__block -->

                <!-- Navigasi utama situs -->
                <nav class="s-header__nav">
                    <ul class="s-header__menu-links">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="about.php">About</a></li>
                        <li><a href="project.php">Project</a></li>
                        <li><a href="skill.php">Skill</a></li>
                        <li><a href="contact.php">Contact</a></li>
                    </ul>
                </nav><!-- end s-header__nav -->

            </div> <!-- end s-header__inner -->
        </header> <!-- end s-header -->

        <!-- Konten utama situs
        ================================================== -->
        <section id="content" class="s-content">
         <?php
        include 'koneksi.php';
        $query = "SELECT name, title, image_path FROM home WHERE id IN (1)";
        $result = $conn->query($query);
        $data = $result->fetch_assoc();
        ?>

            <!-- Intro
            ----------------------------------------------- -->
            <section id="intro" class="s-intro">
                <div class="row s-intro__content width-sixteen-col">

                    <div class="column lg-12 s-intro__content-inner grid-block">
                        
                        <div class="s-intro__content-text">
                            <div class="s-intro__content-pretitle text-pretitle"><?php echo $data['name']; ?></div>
                            <h1 class="s-intro__content-title">
                            <?php echo $data['title']; ?>
                            </h1>
                        </div> <!-- end s-intro__content-text -->

                        <div class="s-intro__content-media"> 
                            <div class="s-intro__content-media-inner">                               
                            <img src="<?php echo $data['image_path']; ?>" alt="foto-el">
                                <div class="lines">                               
                                    <span></span>                                  
                                </div>
                            </div>
                        </div> <!-- end s-intro__content-media -->

                    </div> <!-- end s-intro__content-inner -->
                </div> <!-- end row -->
            </section> <!-- end s-intro -->

        </section> <!-- end s-content -->

        <!-- Footer
        ================================================== -->
        <footer class="column xl-6 lg-12">
            <p class="ss-copyright">
                <span>© Copyright Ellyza Hardianty 2024</span>
            </p>
        </footer> <!-- end footer -->

    </div> <!-- end page-wrap -->

    <!-- JavaScript untuk fungsi halaman
    ================================================== -->
    <script src="js/plugins.js"></script>
    <script src="js/main.js"></script>

</body>
</html>
