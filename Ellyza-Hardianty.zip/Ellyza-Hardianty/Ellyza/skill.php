<!DOCTYPE html>
<html lang="en" class="no-js">

<head>
    <!-- Metadata dasar halaman -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Skill - Ellyza</title>

    <!-- JavaScript untuk menangani skenario tanpa-JS -->
    <script>
        document.documentElement.classList.remove('no-js');
        document.documentElement.classList.add('js');
    </script>

    <!-- Link ke file CSS eksternal -->
    <link rel="stylesheet" href="css/vendor.css">
    <link rel="stylesheet" href="css/styles.css">

    <!-- Ikon favicon untuk berbagai perangkat -->
    <link rel="apple-touch-icon" sizes="180x180" href="apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="favicon-16x16.png">
    <link rel="manifest" href="site.webmanifest">
    <style>
         ul.skills-list {
        list-style-type: none;
        padding: 0;
    }

    .skills-list li {
        margin-bottom: 20px;
        font-family: Arial, sans-serif;
        color: #333;
    }

    /* Style for the progress bar container */
    .progress-container {
        background-color: #e0e0e0;
        width: 100%;
        height: 5px;
        position: relative;
    }

    /* Style for the progress bar */
    .progress-bar {
        background-color: black;
        height: 5px;
    }

    /* Style for the percentage indicator */
    .percentage {
        position: absolute;
        top: -25px;
        background-color: #333;
        color: white;
        font-size: 12px;
        padding: 2px 5px;
        border-radius: 3px;
    }
    </style>
</head>

<body id="top">

    <!-- Preloader sebelum konten utama dimuat -->
    <div id="preloader">
        <div id="loader" class="dots-fade">
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>

    <!-- Pembungkus Halaman Utama -->
    <div id="page" class="s-pagewrap">

        <!-- Header Situs -->
        <header class="s-header">
            <div class="row s-header__inner width-sixteen-col">
                <!-- Navigasi Utama -->
                <nav class="s-header__nav">
                    <ul class="s-header__menu-links">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="about.php">About</a></li>
                        <li><a href="project.php">Project</a></li>
                        <li><a href="skill.php">Skill</a></li>
                        <li><a href="contact.php">Contact</a></li>
                    </ul>
                </nav> <!-- Akhir navigasi utama -->
            </div> <!-- Akhir header__inner -->
        </header> <!-- Akhir header situs -->

        <!-- Konten Utama Halaman -->
        <section id="content" class="s-content">

            <!-- Header Halaman -->
            <section class="s-pageheader pageheader">
                <div class="row">
                    <div class="column xl-12">
                        <h1 class="page-title">
                            <span class="page-title__small-type text-pretitle">My Skill</span>
                            Latest Works
                        </h1>
                    </div>
                </div>
            </section> <!-- Akhir header halaman -->

            <!-- Konten Utama -->
            <section class="s-pagecontent pagecontent">
                <div class="row">
                    <div class="column xl-12 grid-block">

                        <!-- Daftar Skill -->
                        <div class="grid-full grid-list-items">

                          <?php
                               include "koneksi.php";
                             $sql = "SELECT * FROM skill";
                             $result = $conn->query($sql);
                            if ($result->num_rows > 0) {
                                while($row = $result->fetch_assoc()) {
                                    echo '<div class="grid-list-items__item skill-card">';
                                    echo '    <div class="skill-card__header">';
                                    echo '        <div class="skill-card__cat-links">';
                                    echo '            <a href="#">' . htmlspecialchars($row["sekolah"]) . '</a>';
                                    echo '        </div>';
                                    echo '    </div>';
                                    echo '    <div class="skill-card__text">';
                                    echo '        <p style="text-align: justify;">' . htmlspecialchars($row["deskripsi"]) . '</p>';
                                    echo '    </div>';
                                    echo '</div>';
                                }
                            } else {
                                echo "Tidak ada data yang tersedia.";
                            }
                            ?>
                            <!-- Progress Bars for Skills -->
                            <ul class="skills-list">
                                <?php
                                     include "koneksi.php";

                                $sql_skill = "SELECT name, percentage FROM skills";
                                $result_skill = mysqli_query($conn, $sql_skill);
                                
                                if (mysqli_num_rows($result_skill) > 0) {
                                    while ($skill = mysqli_fetch_assoc($result_skill)) {
                                        echo '<li>';
                                        echo '<strong>' . htmlspecialchars($skill['name']) . '</strong>';
                                        echo '<div class="progress-container">';
                                        echo '<div class="progress-bar" style="width:' . $skill['percentage'] . '%;"></div>';
                                        echo '<div class="percentage" style="left: calc(' . $skill['percentage'] . '% - 15px)">' . $skill['percentage'] . '%</div>';
                                        echo '</div>';
                                        echo '</li>';
                                    }
                                } else {
                                    echo "<li>No skills found.</li>";
                                }

                                // Close connection
                                mysqli_close($conn);
                                ?>
                            </ul>

                        </div> <!-- Akhir grid-list-items -->
                    </div> <!-- Akhir kolom grid-block -->
                </div> <!-- Akhir row -->
            </section> <!-- Akhir pagecontent -->
        </section> <!-- Akhir konten utama -->
    </div> <!-- Akhir pembungkus halaman utama -->

    <!-- JavaScript Eksternal -->
    <script src="js/plugins.js"></script>
    <script src="js/main.js"></script>
</body>

</html>
