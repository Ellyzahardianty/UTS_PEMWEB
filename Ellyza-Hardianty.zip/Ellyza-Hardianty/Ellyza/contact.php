<?php
include "koneksi.php";
session_start(); 
$messageSent = false; // Variabel untuk melacak apakah pesan sudah dikirim
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = htmlspecialchars($_POST['name']);
    $email = htmlspecialchars($_POST['email']);
    $gender = htmlspecialchars($_POST['gender']);
    $message = htmlspecialchars($_POST['message']);
    $sendCopy = isset($_POST['copy']) ? 1 : 0;

    // Query untuk memasukkan data ke tabel contact
    $sql = "INSERT INTO contact (name, email, gender, message, send_copy)
            VALUES ('$name', '$email', '$gender', '$message', $sendCopy)";

    if ($conn->query($sql) === TRUE) {
        $_SESSION['message_sent'] = true; // Simpan status pengiriman di session
        $_SESSION['name'] = $name; // Simpan nama untuk pesan sukses
    }
    // Redirect ke halaman yang sama untuk menghindari pengiriman ulang form saat refresh
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en" class="no-js">
<head>
    <!--- Kebutuhan dasar halaman
    ================================================== -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Contact - Ellyza</title>

    <!-- Menambahkan class 'js' pada elemen HTML jika JavaScript aktif -->
    <script>
        document.documentElement.classList.remove('no-js');
        document.documentElement.classList.add('js');
    </script>

    <!-- CSS untuk tampilan halaman -->
    <link rel="stylesheet" href="css/vendor.css">
    <link rel="stylesheet" href="css/styles.css">

    <!-- Ikon favorit
    ================================================== -->
    <link rel="apple-touch-icon" sizes="180x180" href="apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="favicon-16x16.png">
    <link rel="manifest" href="site.webmanifest">

    <style>
        /* Mengatur form untuk berada di tengah layar dan memberikan gaya tambahan */
        .form-container {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 80vh;
            background-color: #f5f5f5; /* Warna latar belakang untuk form */
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>

<body id="top">

    <!-- Preloader untuk animasi loading sebelum halaman selesai dimuat -->
    <div id="preloader">
        <div id="loader" class="dots-fade">
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>

    <!-- Bungkus halaman utama -->
    <div id="page" class="s-pagewrap">

        <!-- Header situs -->
        <header class="s-header">
            <div class="row s-header__inner width-sixteen-col">
                <div class="s-header__block">
                    <div class="s-header__logo">
                        <!-- Tempat logo situs -->
                    </div>
                <!-- Navigasi utama situs -->
                <nav class="s-header__nav">
                    <ul class="s-header__menu-links">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="about.php">About</a></li>
                        <li><a href="Project.php">Project</a></li>
                        <li><a href="skill.php">Skill</a></li>
                        <li><a href="contact.php">Contact</a></li>
                    </ul>
                </nav> <!-- end s-header__nav -->
            </div> <!-- end s-header__inner -->
        </header> <!-- end s-header -->

        <!-- Konten utama situs -->
        <section id="content" class="s-content">

            <!-- Judul halaman -->
            <section class="s-pageheader pageheader">
                <div class="row">
                    <div class="column xl-12">
                        <h1 class="page-title">
                            <span class="page-title__small-type text-pretitle">Contact</span>
                            Get In Touch
                        </h1>
                    </div>
                </div>
            </section> <!-- end pageheader -->

            <!-- Form kontak dengan latar tengah -->
            <div class="row form-container">
             <div class="column xl-6 md-12">
        <?php if (isset($_SESSION['message_sent']) && $_SESSION['message_sent']): ?>
            <!-- Pesan sukses jika data berhasil dikirim -->
            <div class="u-add-bottom">Thank you, <?php echo htmlspecialchars($_SESSION['name']); ?>. Your message has been sent and saved to the database!</div>
            <?php
            // Reset session status setelah menampilkan pesan sukses
            unset($_SESSION['message_sent']);
            unset($_SESSION['name']);
            ?>
        <?php else: ?>
            <!-- Tampilkan form jika pesan belum dikirim -->
            <h3 class="u-add-bottom">Form Contact</h3>

            <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST">
                <div>
                    <label for="sampleInput">Your Name</label>
                    <input class="u-fullwidth" type="text" placeholder="Write Your Name" id="sampleInput" name="name" required>
                </div>
                <div>
                    <label for="email">Your Email</label>
                    <input class="u-fullwidth" type="email" placeholder="test@mailbox.com" id="email" name="email" required>
                </div>
                <div>
                    <label for="gender">Gender</label>
                    <div class="ss-custom-select">
                        <select class="u-fullwidth" id="gender" name="gender" required>
                            <option value="Female">Female</option>
                            <option value="Male">Male</option>
                            <option value="Others">Others</option>
                        </select>
                    </div>
                </div>
                <div>
                    <label for="message">Message</label>
                    <textarea class="u-fullwidth" placeholder="Write your message here" id="message" name="message" required></textarea>
                </div>
                <div class="u-add-bottom">
                    <label>
                        <input type="checkbox" name="copy">
                        <span class="label-text">Send a copy to yourself</span>
                    </label>
                </div>
                <input class="btn--primary u-fullwidth" type="submit" value="Submit">
            </form>
        <?php endif; ?>
    </div>
</div>

        </section> <!-- end s-content -->
        
    </div> <!-- end page-wrap -->

    <!-- JavaScript untuk fungsi halaman -->
    <script src="js/plugins.js"></script>
    <script src="js/main.js"></script>

</body>
</html>
