<!-- header.php -->
<header class="s-header navbar-background">
    <div class="row s-header__inner width-sixteen-col">

        <!-- Navigasi halaman -->
        <nav class="s-header__nav">
            <ul class="s-header__menu-links">
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="project.php">Project</a></li>
                <li><a href="skill.php">Skill</a></li>
                <li><a href="contact.php">Contact</a></li>
            </ul>
        </nav> <!-- end s-header__nav -->
    </div> <!-- end s-header__inner -->
</header> <!-- end s-header -->
